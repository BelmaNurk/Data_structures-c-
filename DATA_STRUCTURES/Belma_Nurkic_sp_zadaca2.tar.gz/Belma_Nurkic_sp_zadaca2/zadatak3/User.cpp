// Vas kod ovdje
#include"User.hpp"

User::User(const std::string& ime, const std::string& prezime, int ID):
  ime_{ime}, prezime_{prezime}, ID_{ID}{}
  
int User::get_ID()const{
    return ID_;
  }
std::string User::get_ime()const{
  return ime_;
}
std::string User::get_prezime()const{
  return prezime_;
}
