// Vas kod ovdje
#include<iostream>
#include<string>
class User{
  public:
  User(const std::string& ime, const std::string& prezime, int ID);
  int get_ID()const;
  std::string get_ime()const;
  std::string get_prezime()const;
  private:
  std::string ime_;
  std::string prezime_;
  int ID_;
};
