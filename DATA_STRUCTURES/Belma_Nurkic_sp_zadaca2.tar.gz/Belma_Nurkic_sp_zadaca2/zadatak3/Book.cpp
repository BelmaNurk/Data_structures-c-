// Vas kod ovdjie
#include"Book.hpp"
Book::Book(const std::string& naslov, const std::string& autor, const std::string izdavac, int godina, int broj):
  naslov_knjige_{naslov}, autor_knjige_{autor}, izadavac_knjige_{izdavac}, godina_izdanja_{godina}, broj_primjeraka_{broj}{}
  
std::string Book::get_naslov()const{
    return naslov_knjige_;
  }
std::string Book::get_autor()const{
    return autor_knjige_;
  }
std::string Book::get_izdavac()const{
    return izadavac_knjige_;
  }
int Book::get_godina()const{
    return godina_izdanja_;
  }
int Book::get_broj()const{
    return broj_primjeraka_;
  }

std::ostream& operator<<(std::ostream& out, const Book& knjiga ){
  out<<knjiga.get_naslov()<<" "<<knjiga.get_autor()<<" ";
  out<<knjiga.get_izdavac()<<" "<<knjiga.get_godina();
  out<<knjiga.get_broj();
  return out;
}
