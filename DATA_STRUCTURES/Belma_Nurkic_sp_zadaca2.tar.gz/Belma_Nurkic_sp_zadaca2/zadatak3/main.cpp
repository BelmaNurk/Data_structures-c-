// Vas kod ovdje
#include"Library.hpp"
//#include"User.hpp"
//#include"Book.hpp"
int main(){

  Library nasa_biblioteka;
  std::string okvir(40,'=');
  std::cout<<okvir<<std::endl;
  std::cout<<"Universisty of Tuzla"<<std::endl;
  std::cout<<"Faculity of electrical engineering"<<std::endl;
  std::cout<<std::endl;
  std::cout<<std::endl;
  std::cout<<"Library application"<<std::endl;
  std::cout<<"Version: April 2023."<<std::endl;
  std::cout<<std::endl;
  std::cout<<std::endl;
  std::cout<<okvir;
  std::cout<<std::endl;
  std::string okvir1(40, '-');
  std::cout<<okvir1<<std::endl;
  std::cout<<"List of commands:"<<std::endl;
  std::cout<<okvir<<std::endl;
  std::cout<<"CreateUser"<<std::endl;
  std::cout<<"BookAdd"<<std::endl;
  std::cout<<"BookBorrow"<<std::endl;
  std::cout<<"BookReturn"<<std::endl;
  std::cout<<"BookSearchByTitle"<<std::endl;
  std::cout<<"BookSearchByAuthor"<<std::endl;
  std::cout<<"BookSearchByPublisher"<<std::endl;
  std::cout<<"BookSearchByPublicationYear"<<std::endl;
  std::cout<<"Help"<<std::endl;
  std::cout<<"Exit"<<std::endl;
  std::cout<<okvir1<<std::endl;
  std::string okvir2(40,'.');
  //std::cout<<okvir2<<std::endl;

  while(true){
    std::cout<<okvir2<<std::endl;
  std::cout<<"Enter command: ";
  std::string command;
    std::cin>>command;
    std::cin.clear();
    std::cout<<okvir2<<std::endl;
  if(command=="CreateUser"){
    std::string ime;
    std::string prezime;
    int ID;
    std::cout<<"First name: ";
    std::cin>>ime;
    std::cout<<"Last name ";
    std::cin>>prezime;
    std::cout<<"User ID: ";
    std::cin>>ID;
    User novi_clan(ime, prezime, ID);
    nasa_biblioteka.unesi_clana(novi_clan);
  }
  else if(command=="BookAdd"){
    std::string naslov;
    std::string autor;
    std::string izdavac;
    int godina;
    int broj;
    std::cout<<"Ttile: ";
    std::cin>>naslov;
    std::cout<<"Author: ";
    std::cin>>autor;
    std::cout<<"Publicher: ";
    std::cin>>izdavac;
    std::cout<<"Publication year: ";
    std::cin>>godina;
    std::cout<<"Number of copies: ";
    std::cin>>broj;
    Book nova_knjiga(naslov, autor, izdavac, godina, broj);
    nasa_biblioteka.unesi_knjigu(nova_knjiga);
  }
  else if(command=="BookBorrow"){
    std::string knjiga;
    int id;
    std::cout<<"User ID: ";
    std::cin>>id;
    std::cout<<"Book title: ";
    std::cin>>knjiga;
    nasa_biblioteka.posudjivanje(id, knjiga);
  }
  else if(command=="BookReturn"){
    std::string knjiga;
    int id;
    std::cout<<"User ID: ";
    std::cin>>id;
    std::cout<<"Book title: ";
    std::cin>>knjiga;
    nasa_biblioteka.vracanje(id, knjiga);
  }
  else if(command=="BookSearchByTitle"){
    std::cout<<"Title: ";
    std::string naslov;
    std::cin>>naslov;
    nasa_biblioteka.ispisi_po_nazivu(naslov);
  }
  else if(command=="BookSearchByAuthor"){
    std::cout<<"Author: ";
    std::string autor;
    std::cin>>autor;
    nasa_biblioteka.ispisi_po_autoru(autor);
  }
  else if(command=="BookSearchByPublicer"){
    std::cout<<"Publicer: ";
    std::string izdavac;
    std::cin>>izdavac;
    nasa_biblioteka.ispisi_po_izdacacu(izdavac);
  }
  else if(command=="BookSreachByYear"){
    std::cout<<"Year: ";
    int year;
    std::cin>>year;
    nasa_biblioteka.ispisi_po_godini(year);
  }
  else if(command=="Exit"){
    exit(0);
  }
  else if(command=="Help"){
  std::cout<<"List of commands:"<<std::endl;
  std::cout<<okvir<<std::endl;
  std::cout<<"CreateUser"<<std::endl;
  std::cout<<"BookAdd"<<std::endl;
  std::cout<<"BookBorrow"<<std::endl;
  std::cout<<"BookReturn"<<std::endl;
  std::cout<<"BookSearchByTitle"<<std::endl;
  std::cout<<"BookSearchByAuthor"<<std::endl;
  std::cout<<"BookSearchByPublisher"<<std::endl;
  std::cout<<"BookSearchByPublicationYear"<<std::endl;
  std::cout<<"Help"<<std::endl;
  std::cout<<"Exit"<<std::endl;
  }
  else{
    std::cout<<"Invalid command, try again."<<std::endl;
  }


  }
  return 0;
}
