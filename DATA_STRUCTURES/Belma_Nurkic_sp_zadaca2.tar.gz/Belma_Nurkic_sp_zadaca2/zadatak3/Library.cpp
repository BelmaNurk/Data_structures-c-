// Vas kod ovdje
#include"Library.hpp"


User Library::unesi_clana(const User& clan){
    for(int i=0; i<clanovi_.size(); ++i){
      if(clanovi_[i].get_ID()==clan.get_ID()){
        std::cout<<"User with ID {"<<clan.get_ID()<<"} already exist. "<<std::endl;
        return clanovi_[i];
      }
    }
    clanovi_.push_back(clan);
    std::cout<<"User created successfully."<<std::endl;
    return clan;
}

void Library::vracanje(int userID, std::string naslov){
  int returned=0;
  for(int i=0; i<posudjene_knjige.size(); ++i){
    if(posudjene_knjige.at(i).get_naslov()==naslov){
      posudjene_knjige.erase(posudjene_knjige.begin()+i);
      std::cout<<"Book successfully returned."<<std::endl;
        returned=1;
    }

  }
  if(returned==0)
  std::cout<<"Book not found."<<std::endl;

}
void Library::posudjivanje(int userID, std::string naslov){
  int borrow=0;
    for(int j=0; j<clanovi_.size(); ++j){
      if(clanovi_[j].get_ID()==userID){
    for(int i=0;i<duznici_knjiga.size(); ++i){
      if(userID==duznici_knjiga[i].get_ID()){
        borrow=1;
        std::cout<<"This user can not borrow a book"<<std::endl;
      break;
      }
    }
    duznici_knjiga.push_back(clanovi_[j]);

    if(borrow==0){
      for(int i=0; i<knjige_.size(); ++i){
        if(knjige_.at(i).get_naslov()==naslov){
          posudjene_knjige.push_back(knjige_.at(i));

        }
      }
    std::cout<<"Book successfully borrowed."<<std::endl;
      }
    }
}
}

Book Library::unesi_knjigu(const Book& knjiga){
  knjige_.push_back(knjiga);
  std::cout<<"Book successfully added."<<std::endl;
  return knjiga;
}
  void Library::ispisi_po_nazivu(const std::string& naslov){
    bool postoji_knjiga=0;
    for(int i=0; i<get_knjige().size(); ++i){
      if(get_knjige().at(i).get_naslov()==naslov){
          std::cout<<get_knjige().at(i)<<std::endl;
          postoji_knjiga=1;
    }
    }
    if(postoji_knjiga==0)
    std::cout<<"Book not found."<<std::endl;
  }

  void Library::ispisi_po_autoru(const std::string& autor){
    bool postoji_knjiga=0;
   for(int i=0; i<get_knjige().size(); ++i){
      if(get_knjige().at(i).get_autor()==autor){
          std::cout<<get_knjige().at(i)<<std::endl;
          postoji_knjiga=1;
    }
    }
   if(postoji_knjiga==0)
     std::cout<<"Book not found."<<std::endl;
    }
  void Library::ispisi_po_izdacacu(const std::string& izdavac){
    bool postoji_knjiga=0;
    for(int i=0; i<get_knjige().size(); ++i){
      if(get_knjige().at(i).get_izdavac()==izdavac){
          std::cout<<get_knjige().at(i)<<std::endl;
          postoji_knjiga=1;
    }
    }
    if(postoji_knjiga==0)
    std::cout<<"Book not found."<<std::endl;
  }

  void Library::ispisi_po_godini(int godina){
    bool postoji_knjiga=0;
   for(int i=0; i<get_knjige().size(); ++i){
      if(get_knjige().at(i).get_godina()==godina){
          std::cout<<get_knjige().at(i)<<std::endl;
          postoji_knjiga=1;
    }
    }
   if(postoji_knjiga==1)
   std::cout<<"Book not found"<<std::endl;
  }
std::vector<Book> Library::get_knjige()const{
  return knjige_;
}
