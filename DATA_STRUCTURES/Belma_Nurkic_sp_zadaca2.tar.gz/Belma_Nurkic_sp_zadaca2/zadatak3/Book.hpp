// Vas kod ovdje
#include<iostream>
#include<string>
class Book{
  public:
  Book(const std::string& naslov, const std::string& autor, const std::string izdavac, int godina, int broj);
  std::string get_naslov()const;
  std::string get_autor()const;
  std::string get_izdavac()const;
  int get_godina()const;
  int get_broj()const;
  private:
    std::string naslov_knjige_;
    std::string autor_knjige_;
    std::string izadavac_knjige_;
    int godina_izdanja_;
    int broj_primjeraka_;
};

std::ostream& operator<<(std::ostream& out, const Book& knjiga);
