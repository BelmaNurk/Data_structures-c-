// Vas kod ovdje
#include<iostream>
#include<vector>
#include"Book.hpp"
#include"User.hpp"

class Library{
  public:
  User unesi_clana(const User& clan);
  Book unesi_knjigu(const Book& knjiga);
  void posudjivanje(int userID, std::string naslov);
  void vracanje(int userID, std::string naslov);
  void vracanje(int userID);
  void ispisi_po_nazivu(const std::string& naslovu);
  void ispisi_po_autoru(const std::string& autor);
  void ispisi_po_izdacacu(const std::string& izdavac);
  void ispisi_po_godini(int godina);
  std::vector<Book> get_knjige()const;
  

  private:
  std::string naziv="FETLibrary";
  std::vector<Book> knjige_;
  std::vector<User> duznici_knjiga;
  std::vector<Book> posudjene_knjige;
  std::vector<User> clanovi_;
};
