#pragma once
#include<iostream>
#include <initializer_list>
#include <iterator>


template <typename T>
class MojVektor {

  public:
  class Iterator;

  MojVektor(){
    capacity_=10;
    size_=0;
    arr_=new T[capacity_];
  }

  MojVektor(const std::initializer_list<T>& lista){
    capacity_=lista.size()+10;
    size_=lista.size();
    arr_=new T[capacity_];
    std::copy(lista.begin(), lista.begin()+size_, arr_);
  }

  MojVektor(const MojVektor& other){
    capacity_=other.capacity_;
    size_=other.size_;
    arr_=new T[capacity_];
    std::copy(other.arr_, other.arr_+size_, arr_);
  }

  MojVektor& operator=(const MojVektor& other){
    if(this!=&other){
      delete[]arr_;
      capacity_=other.capacity_;
      size_=other.size_;
      arr_=new T[capacity_];
      std::copy(other.arr_, other.arr_+size_, arr_);
    }
    return *this;
  }

  MojVektor(MojVektor&& other){
    capacity_=other.capacity_;
    size_=other.size_;
    arr_=std::move(other.arr_);
    other.capacity_=other.size_=0;
    other.arr_=nullptr;
  }

  MojVektor& operator=(MojVektor&& other){
    delete [] arr_;
    capacity_=other.capacity_;
    size_=other.size_;
    arr_=std::move(other.arr_);
    other.size_=other.capacity_=0;
    other.arr_=nullptr;
    return *this;
  }

  ~MojVektor(){
    if(arr_!=nullptr){
      delete []arr_;
      size_=capacity_=0;
      arr_=nullptr;
    }
  }

  MojVektor& push_back(const T& value){
    if(size_==capacity_)
      realoc();
    arr_[size_++]=value;
    return *this;
  }

  MojVektor& push_front(const T& value){
    if(size_==capacity_)
      realoc();
    for(int i=size_; i>0; i--){
      arr_[i]=arr_[i-1];
    }
    size_++;
    arr_[0]=value;
    return *this;
  }

  MojVektor& push_back(T&& value){
    if(size_==capacity_)
      realoc();
    arr_[size_++]=std::move(value);
    return *this;
  }

  MojVektor& push_front(T&& value){
    if(size_==capacity_)
      realoc();
    for(int i=size_; i>0; i--){
      arr_[i]=arr_[i-1];
    }
    size_++;
    arr_[0]=std::move(value);
    return *this;
  }

  size_t size() const{
    return size_;
  }

  T& at(size_t index) const{
    if(index>=size_||index<0)
      throw std::out_of_range("Invalid index!");
    return arr_[index];
  }

  T& operator[](size_t index) const{
    return arr_[index];
  }

  void clear(){
    size_=0;
    capacity_=0;
    delete []arr_;
    arr_=nullptr;
  }

  void resize(size_t newSize, const T& difference_value){
    if(newSize<size_)
      size_=newSize;
    else if(newSize>size_){
      T* temp=arr_;
      arr_=new T[newSize];
      std::copy(temp, temp+size_, arr_);
      capacity_=newSize;
      for(int i=size_; i<newSize; ++i){
        arr_[i]=difference_value;
      }
      size_=newSize;
      delete[] temp;
    }
  }

  MojVektor& pop_back(){
    if(empty())
      throw std::out_of_range("Vector is empty.");
    size_--;
    return *this;
  }

  MojVektor& pop_front(){
    if(empty())
      throw std::out_of_range("Vector is empty.");
    for(int i=0; i<size_-1; ++i){
      arr_[i]=arr_[i+1];
    }
    size_--;
    return *this;
  }

  T& back() const{
    if(empty())
      throw std::out_of_range("Vector is empty.");
    return arr_[size_-1];
  }

  T& front() const{
    if(empty())
      throw std::out_of_range("Vector is empty.");
    return arr_[0];
  }

  bool empty() const{
    return size_==0;
  }

  size_t capacity() const{
    return capacity_;
  }

  bool operator==(const MojVektor& other) const{
    if(size_==0 & other.size_==0)
      return true;
    else if(size_==0 || other.size_==0)
      return false;
    for(int i=0; i<size_; ++i){
      if(arr_[i]!=other.arr_[i])
        return false;
    }
      return true;
  }

  bool operator!=(const MojVektor& other) const{
    return !(arr_==other.arr_);
  }

  bool full() const{
    return size_==capacity_;
  }

 MojVektor subvector(Iterator begin, Iterator end){
   MojVektor<T> subvec;
   while(begin!=end){
     subvec.push_back(*begin);
     ++begin;
   }
   return subvec;
 }

  Iterator begin() const{
    if(empty())
      return end();
    return Iterator(arr_);
  }

  Iterator end() const{
    return arr_+size_;
  }

  Iterator find(const T& value) const{
    if(!empty()){
    for(auto iter=begin(); iter!=end(); ++iter){
      if(*iter==value)
        return iter;
    }
    }
    return end();
  }
  
  Iterator erase(Iterator pos){
    if(pos==end())
      return end();
    auto ret=pos;
    auto it=pos+1;
    while(it!=end()){
      *pos++=*it++;
    }
    --size_;
    return ret;
  }

  Iterator insert(Iterator pos, const T& value){
    if(pos<begin() || pos>=end())
      throw std::out_of_range("Invalid position.");
    if(size_==capacity_)
      realoc();
    for(auto iter=end(); iter>pos; --iter){
      *iter=std::move(*(iter-1));

    }
    *pos=value;
    size_++;
    return pos;
  }


 Iterator insert(Iterator pos, T&& value){
   if(pos<begin()||pos>=end())
     throw std::out_of_range("Invalid position");
   if(size_==capacity_)
     realoc();
   for(auto iter=end(); iter>pos; --iter){
     *iter=std::move(*(iter-1));
   }
   *pos=std::move(value);
   size_++;
   return pos;
 }

  Iterator rbegin() const{
    return end()-1;
  }

  Iterator rend() const{
    return begin()-1;
  }

  Iterator erase(Iterator beginIt, Iterator endIt){
      auto temp=beginIt;
    while(temp!=endIt){
      erase(beginIt);
      ++temp;
    }
    std::cout<<size_;
    
return beginIt;

  }

  void rotate(){
    auto iter1=begin();
    auto iter2=end();
    while(iter1<iter2){
      std::swap(*iter1, *(iter2-1));
      ++iter1;
      --iter2;
    }
    }

  void rotate(Iterator beginIt, Iterator endIt){
    auto temp=beginIt;
    auto temp1=endIt;
    while(temp<temp1){
    std::swap(*temp, *(temp1-1));
      ++temp;
      --temp1;

    }
  }


  T* data(){
    return arr_;
  }

  private:
  void realoc(){
    T* new_arr=new T[2*capacity_];
    for(int i=0; i<size_; ++i){
      new_arr[i]=arr_[i];
    }
    delete [] arr_;
    arr_=new_arr;
    capacity_=2*capacity_;

  }
  
  size_t capacity_;
  size_t size_;
  T* arr_;
  public:
  class Iterator{
    public:
      Iterator(){
        ptr_=nullptr;
      }
      Iterator( T* iter){
        ptr_=iter;
      }
      Iterator(const Iterator& other){
        ptr_=other.ptr_;
      }
      Iterator(Iterator&& other){
        ptr_=std::move(other.ptr_);
        other.ptr_=nullptr;
      }
      Iterator& operator=(const Iterator& other){
        if(this!=&other){
        //delete ptr_;
        //T* temp=other.ptr_;
        *ptr_=*other.ptr_;
        }
        return *this;
      }
      Iterator& operator=(Iterator&& other){
       // delete ptr_;
         //T* temp=other.ptr_;
         ptr_=other.ptr_;
        other.ptr_=nullptr;
        return *this;
      }
     // ~Iterator(){
     //   delete ptr_;
     //   ptr_=nullptr;
    //  }


      T* operator->(){
        return ptr_;
      }
      T& operator*(){
        return *ptr_;
      }
      T* operator[](int index){
        return ptr_+index;
      }
      Iterator& operator+(const Iterator& other){
        return ptr_+other.ptr_;
      }
      Iterator operator+(size_t n){
        return ptr_+n;
      }
      Iterator& operator-(const Iterator& other){
        return ptr_-other.ptr_;
      }
      Iterator operator-(size_t n){
        return ptr_-n;
      }
      bool operator==(const Iterator& other){
        return ptr_==other.ptr_;
      }
      bool operator!=(const Iterator& other){
        return ptr_!=other.ptr_;
      }
      bool operator>(const Iterator& other){
        return ptr_>other.ptr_;
      }
      bool operator<(const Iterator& other){
        return ptr_<other.ptr_;
      }
      bool operator>=(const Iterator& other){
        return ptr_>=other.ptr_;
      }
      bool operator<=(const Iterator& other){
        return ptr_<=other.ptr_;
      }
      Iterator& operator++(){
        ++ptr_;
        return *this;
      }
      Iterator& operator--(){
        --ptr_;
        return *this;
      }
      Iterator operator++(int){
        auto temp=*this;
        ++ptr_;
        return temp;
      }
      Iterator operator--(int){
        auto temp=*this;
        --ptr_;
        return temp;
      }
      
    private:
      T* ptr_;
  };
};
template<typename T>
std::ostream& operator<<(std::ostream& out,const MojVektor<T>& vec){
  if(vec.empty())
    out<<"{}";
  else if(vec.size()==1){
    out<<"{"<<vec.at(0)<<"}";
  }
  else{
    out<<'{';
      for(int i=0; i<vec.size()-1; ++i){
        out<<vec.at(i)<<", ";
      }
    out<<vec.at(vec.size()-1)<<'}';

  }
  return out;

}

