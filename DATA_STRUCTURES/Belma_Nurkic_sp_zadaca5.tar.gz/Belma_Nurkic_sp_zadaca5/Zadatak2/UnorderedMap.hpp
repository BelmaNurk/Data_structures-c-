#pragma once
#include <algorithm>
#include <iostream>
#include <list>
#include <string>
#include <vector>

template <typename Key_t, typename Value_t>
class UnorderedMap {
  public:
  class Iterator;

  using key_type = Key_t;
  using mapped_type = Value_t;
  using value_type = std::pair<key_type, mapped_type>;
  using bucket_type = std::list<value_type>;

  UnorderedMap() : buckets_{std::vector<bucket_type>(capacity_)} {}

  static size_t hash(const key_type& key) {
    size_t sum = 5381;
    for (char c : key) {
      sum += (sum << 4) + c;
    }
    return sum;
  }

  void emplace(const key_type& key, const mapped_type& value) {
    auto index = hash(key) % capacity_;
    auto& bucket = buckets_[index];
    auto it =
        find_if(bucket.begin(), bucket.end(),
                [&key](const auto& element) { return element.first == key; });
    if (it != bucket.end()) {
      throw std::invalid_argument{"ELement with this key already exists"};
    } else {
      bucket.push_back(value_type(key, std::move(value)));
    }
  }

  mapped_type& operator[](const key_type& key) {
    auto index = hash(key) % capacity_;
    auto& bucket = buckets_[index];
    if (bucket.empty()) {
      emplace(key, mapped_type{});
    } else {
      for (auto& pair : bucket) {
        if (pair.first == key) return pair.second;
      }
      emplace(key, mapped_type{});
    }
    mapped_type& ret = bucket.begin()->second;
    for (auto& pair : bucket) {
      if (pair.first == key) {
        ret = pair.second;
        break;
      }
    }
    return ret;
  }

  bool erase(const key_type& key) {
    auto index = hash(key) % capacity_;
    auto& bucket = buckets_[index];
    if (bucket.empty()) return false;
    auto it =
        find_if(bucket.begin(), bucket.end(),
                [&key](const auto& element) { return element.first == key; });
    if (it != bucket.end()) {
      bucket.erase(it);
      return true;
    }
    return false;
  }

  Iterator find(const key_type& key) {
    auto index = hash(key) % capacity_;
    auto& bucket = buckets_[index];
    if (bucket.empty())
      throw std::invalid_argument{"Pair with this key does not exist!"};
    auto it = std::find_if(
        bucket.begin(), bucket.end(),
        [&key](const auto& element) { return element.first == key; });
    if (it != bucket.end()) return Iterator{buckets_, bucket.begin()};
    return end();
  }

  Iterator find(key_type& other) {
    auto index = hash(other) % capacity_;
    auto& bucket = buckets_[index];
    bool exist = false;
    if (buckets_.empty())
      throw std::invalid_argument{"Pair with this key does not exist!"};
    auto begin = bucket.begin();
    while (begin != bucket.end()) {
      auto key = begin->first;
      if (key == other) {
        exist = true;
      }
      ++begin;
    }
    if (exist) {
      return Iterator{buckets_, begin};
    } else {
      return end();
    }
  }

  Iterator end() { return Iterator{buckets_, buckets_[capacity_ - 1].end()}; }

  Iterator begin() { return Iterator{buckets_}; }

  class Iterator : public std::bidirectional_iterator_tag {
public:
    Iterator(std::vector<bucket_type>& other_b,
             typename bucket_type::iterator other)
        : bucketsRef_{other_b}, current_{other} {}

    Iterator(std::vector<bucket_type>& other, bool isBegin = true)
        : bucketsRef_{other} {
      if (isBegin) {
        int index = 0;
        for (auto i = 0; i < bucketsRef_.size(); ++i) {
          if (!bucketsRef_[i].empty()) {
            index = i;
            break;
          }
        }
        auto& bucket = bucketsRef_[index];
        current_ = bucket.begin();
      } else {
        int index = 0;
        for (auto i = 0; i < bucketsRef_.size(); ++i) {
          if (!bucketsRef_[i].empty()) {
            index = i;
          }
        }
        auto& bucket = bucketsRef_[index];
        current_ = bucket.end();
      }
    }

    Iterator(const Iterator& other)
        : bucketsRef_{other.bucketsRef_}, current_{other.current_} {}

    Iterator(Iterator&& other)
        : bucketsRef_{other.bucketsRef_}, current_{other.current_} {}
    Iterator& operator++() {
      auto key = current_->first;
      auto index = hash(key) % capacity_;
      auto& bucket = bucketsRef_[index];
      auto tmp = current_;

      if (++tmp != bucket.end()) {
        ++current_;
      } else {
        auto i = index + 1;
        for (; i < bucketsRef_.size(); ++i) {
          if (!bucketsRef_[i].empty()) {
            index = i;
            break;
          }
        }
        if (i < bucketsRef_.size()) {
          current_ = bucketsRef_[index].begin();
        } else {
          current_ = bucketsRef_[capacity_ - 1].end();
        }
      }
      return *this;
    }

    Iterator& operator++(int) {
      static Iterator ret = *this;
      auto key = current_->first;
      auto index = hash(key) % capacity_;
      auto& bucket = bucketsRef_[index];
      auto tmp = current_;

      if (++tmp != bucket.end()) {
        ++current_;
      } else {
        auto i = index + 1;
        for (; i < bucketsRef_.size(); ++i) {
          if (!bucketsRef_[i].empty()) {
            index = i;
            break;
          }
        }
        if (i < bucketsRef_.size()) {
          current_ = bucketsRef_[index].begin();
        } else {
          current_ = bucketsRef_[capacity_ - 1].end();
        }
      }
      return ret;
    }

    Iterator& operator--() {
      auto key = current_->first;
      auto index = hash(key) % capacity_;
      auto& bucket = bucketsRef_[index];
      auto tmp = current_;
      if (--tmp != bucket.begin()) {
        --current_;
      } else {
        for (auto i = index - 1; i < bucketsRef_.size(); ++i) {
          if (!bucketsRef_[i].empty()) {
            index = i;
            break;
          }
        }
        if (index >= 0) {
          current_ = bucketsRef_[index].begin();
        }
      }
      return *this;
    }

    Iterator& operator--(int) {
      static Iterator ret = *this;
      auto key = current_->first;
      auto index = hash(key) % capacity_;
      auto& bucket = bucketsRef_[index];
      auto tmp = current_;
      if (--tmp != bucket.begin()) {
        --current_;
      } else {
        for (auto i = index - 1; i < bucketsRef_.size(); ++i) {
          if (!bucketsRef_[i].empty()) {
            index = i;
            break;
          }
        }
        if (index >= 0) {
          current_ = bucketsRef_[index].begin();
        }
      }
      return ret;
    }

    //    bool operator==(typename bucket_type::iterator other) { return
    //    current_ == other; } bool operator!=(typename bucket_type::iterator
    //    other) { return current_ != other; }

    bool operator==(const Iterator& other) {
      return current_ == other.current_;
    }

    bool operator!=(const Iterator& other) {
      return current_ != other.current_;
    }

    typename bucket_type::iterator operator->() const { return current_; }

private:
    std::vector<bucket_type>& bucketsRef_;
    typename bucket_type::iterator current_;
  };

  private:
  const static int capacity_{10000};
  size_t size_{0};
  std::vector<bucket_type> buckets_;
};

