#include "heap.hpp"

int main() {
  using Types::Heap;
  Heap<int> heap;
  heap.insert(-4).insert(-10).insert(-50).insert(1000).insert(5);
  // expected --> 1000, 5, -50, -10, -4
  heap.printNormal(heap);
  // expected --> -10, 5, -4, 1000, -50
  std::cout << heap << std::endl;
  heap.removeMax();
  // exxpected --> 5, -4, -50, -10
  heap.printNormal(heap);
  heap.removeMin();
  // expected --> 5, -4, -10
  heap.printNormal(heap);
  // expected --> -4 5 -10
  std::cout << heap << std::endl;

  Heap<int> heap2;
  heap2.insert(-100).insert(30).insert(-20).insert(0).insert(30);
  std::cout << "Heap2 : ";
  heap2.printNormal(heap2);
  std::cout << "Minimal value(heap2): " << heap2.min() << std::endl;
  std::cout << "Maximal value(heap2): " << heap2.max() << std::endl;
}
