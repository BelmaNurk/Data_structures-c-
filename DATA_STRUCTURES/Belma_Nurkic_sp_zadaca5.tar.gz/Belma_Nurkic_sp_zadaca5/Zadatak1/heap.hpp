#pragma once
#include <algorithm>
#include <iostream>

namespace Types {

template <typename T>
void printInorder(T* arr, T start, const size_t end) {
  if (start > end) return;
  printInorder(arr, start * 2 + 1, end);
  std::cout << arr[start] << " ";
  printInorder(arr, start * 2 + 2, end);
}

template <typename T>
class Heap {
  public:
  Heap() : capacity_{10}, size_{0}, arr_{new T[capacity_]} {}

  Heap(const Heap& heap)
      : size_{heap.size_}, capacity_{heap.capacity_}, arr_{new T[capacity_]} {
    std::copy(heap.arr_, heap.arr_ + size_, arr_);
  }

  Heap(Heap&& heap)
      : size_{heap.size_}, capacity_{heap.capacity_}, arr_{heap.arr_} {
    heap.arr_ = nullptr;
  }

  Heap& operator=(const Heap& heap) {
    if (heap != &this) {
      delete[] arr_;
      size_ = heap.size_;
      capacity_ = heap.capacity_;
      arr_ = new T[capacity_];
      std::copy(heap.arr_, heap.arr_ + size_, arr_);
    }
    return *this;
  }

  Heap& operator=(Heap&& heap) {
    delete[] arr_;
    capacity_ = heap.capacity_;
    size_ = heap.size_;
    arr_ = heap.arr_;
    heap.arr_ = nullptr;
    return *this;
  }
  ~Heap() { delete[] arr_; }

  // ostream --> inorder prolazak
  friend std::ostream& operator<<(std::ostream& os, const Heap& heap) {
    os << "[";
    printInorder(heap.arr_, 0, heap.size_ - 1);
    os << "]";
    return os;
  }

  // klasicni ispis
  void printNormal(const Heap& heap) {
    std::cout << "[";
    for (int i = 0; i < heap.size_; ++i) {
        std::cout << heap.arr_[i] << " ";
    }
    std::cout << "]" << std::endl;
  }

  T min() {
    auto index = minIndx();
    return arr_[index];
  }

  T max() const { return arr_[0]; }

   void removeMax() {
    if (empty()) return;
    std::swap(arr_[0], arr_[size_ - 1]);
    --size_;
    balanceDown(0);
  }

  void removeMin() {
    if (empty()) return;
    auto index = minIndx();
    std::swap(arr_[size_ - 1], arr_[index]);
    balanceDown(index);
    --size_;
  }

  template <typename U>
  Heap& insert(U&& element) {
    if (full()) realoc();
    arr_[size_++] = std::forward<U>(element);
    if (size_ > 1) balanceUp(size_ - 1);
    return *this;
  }

  T minIndx() {
    int index = 0;
    int minValue = arr_[0];
    for (auto i = 0; i < size_; ++i) {
      if (arr_[i + 1] < arr_[i]) {
        minValue = arr_[i + 1];
        index = i + 1;
      }
    }
    return index;
  }

  void balanceDown(size_t index) {
    if (index < size_) {
      size_t left = (index * 2) + 1;
      size_t right = (index * 2) + 2;
       if (left < size_ && right < size_ &&
          (arr_[index] < arr_[left] || arr_[index] < arr_[right])) {
         size_t maxIdx = arr_[left] < arr_[right] ? right : left;
         std::swap(arr_[index], arr_[maxIdx]);
         balanceDown(maxIdx);
       } else if (left < size_ && right >= size_ && arr_[index] < arr_[left]) {
        std::swap(arr_[index], arr_[left]);
        balanceDown(left);
       } else if (right < size_ && left >= size_ && arr_[index] < arr_[right]) {
        std::swap(arr_[index], arr_[right]);
        balanceDown(right);
      }
    }
  }

  void balanceUp(size_t index) {
   while (index > 0 && arr_[(index - 1) / 2] < arr_[index]) {
      std::swap(arr_[(index - 1) / 2], arr_[index]);
      index = (index - 1) / 2;
    }
  }

  bool empty() const { return size_ == 0; };
  bool full() const { return size_ == capacity_; };
  size_t size() const { return size_; }
  void realoc() {
    T* tmp = new T[capacity_];
    std::copy(arr_, arr_ + size_, tmp);
    delete[] arr_;
    capacity_ *= 2;
    arr_ = new T[capacity_];
    std::copy(tmp, tmp + size_, arr_);
    delete[] tmp;
  }

  private:
  size_t size_;
  size_t capacity_;
  T* arr_;
};
}
