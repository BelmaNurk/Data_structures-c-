#include <iostream>
#include <stack>
#include <sstream>

class PostfixCalc {
public:
    int calculate(const std::string& expression) {
        std::istringstream iss(expression);
        std::string token;
        while (iss >> token) {
            if (isNumber(token)) {
                int operand = std::stoi(token);
                operand_stack.push(operand);
            } else if (isOperator(token)) {
                if (operand_stack.size() < 2) {
                    std::cerr << "Error: Insufficient operands" << std::endl;
                    return 0;
                }
                int operand2 = operand_stack.top();
                operand_stack.pop();
                int operand1 = operand_stack.top();
                operand_stack.pop();
                int result = performOperation(operand1, operand2, token[0]);
                operand_stack.push(result);
            } else {
                std::cerr << "Error: Invalid token - " << token << std::endl;
                return 0;
            }
        }
        if (operand_stack.size() != 1) {
            std::cerr << "Error: Invalid expression" << std::endl;
            return 0;
        }
        return operand_stack.top();
    }

private:
    std::stack<int> operand_stack;

    bool isNumber(const std::string& token) {
        return !token.empty() && token.find_first_not_of("0123456789") == std::string::npos;
    }

    bool isOperator(const std::string& token) {
        return token.size() == 1 && token.find_first_of("+-*/") != std::string::npos;
    }

    int performOperation(int operand1, int operand2, char op) {
        switch (op) {
            case '+':
                return operand1 + operand2;
            case '-':
                return operand1 - operand2;
            case '*':
                return operand1 * operand2;
            case '/':
                if (operand2 == 0) {
                    std::cerr << "Error: Division by zero" << std::endl;
                    exit(1);
                }
                return operand1 / operand2;
            default:
                std::cerr << "Error: Invalid operator - " << op << std::endl;
                exit(1);
        }
    }
};

int main() {
    PostfixCalc calculator;
    std::string expression;
    while (std::getline(std::cin, expression)) {
        int result = calculator.calculate(expression);
        std::cout << "Result: " << result << std::endl;
    }
    return 0;
}

