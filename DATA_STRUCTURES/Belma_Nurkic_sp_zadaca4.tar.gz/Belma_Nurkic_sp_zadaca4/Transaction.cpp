#include<iostream>
#include<queue>

int main(){
  std::queue<
  std::cout<<"Actions:"<<std::endl;
  std::cout<<"1. New transaction"<<std::endl;
  std::cout<<"2. Apply transaction"<<std::endl;
  std::cout<<"3. Pending trancastion"<<std::endl;
  std::cout<<"4. Discard pending transaction"<<std::endl;
  std::cout<<"5. Ballance"<<std::endl;
  std::cout<<"6. Exit"<<std::endl;
  std::cout<<"choice"<<std::endl;
  int choice;
  std::cin>>choice;
  if(choice==1){
    std::cout<<"Unesite Vas ID";
    int ID;
    std::cin>>ID;
    

  }
  return 0;
}
