#include "Rational.hpp"
#include <algorithm>
#include <iostream>
#include <numeric>
#include <sstream>
#include<cmath>

Rational::Rational():numerator_{0}, denominator_{1}{}
Rational::Rational(int numerator, int denominator){
  if(denominator==0)
    throw std::invalid_argument("Denominator must be different than 0");
  numerator_=numerator;
  denominator_=denominator;

}
Rational::Rational(const char* rational){
  std::stringstream ss{rational};
  std::string token;
  int numerator;
  int denominator;
  std::getline(ss, token, '/');
  numerator=std::stoi(token);
  std::getline(ss, token, '/');
  denominator=std::stoi(token);
  if(denominator==0)
    throw std::invalid_argument("Denominator must be different than 0");
  int devisor=gcd(numerator, denominator);
  numerator_=numerator/devisor;
  denominator_=denominator/devisor;
}
Rational::Rational(const std::string& rational){
  std::stringstream ss{rational};
  std::string token;
  std::getline(ss, token, '/');
  numerator_=std::stoi(token);
  std::getline(ss, token, '/');
  denominator_=std::stoi(token);
  if(denominator_==0)
    throw std::invalid_argument("Denominator must be different than 0");
  int devisor=gcd(numerator_, denominator_);
  numerator_=numerator_/devisor;
  denominator_=denominator_/devisor;

}
Rational::Rational(const Rational& rational):numerator_{rational.numerator_}, denominator_{rational.denominator_}{}
Rational::Rational(Rational&& rational){
  numerator_=std::move(rational.numerator_);
  denominator_=std::move(rational.denominator_);
  rational.numerator_=0;
  rational.denominator_=1;

}

Rational& Rational::operator=(const Rational& rational){
  if(this!=&rational){
    numerator_=rational.numerator_;
    denominator_=rational.denominator_;
  }
  return *this;
}

Rational& Rational::operator=(Rational&& rational){
  numerator_=std::move(rational.numerator_);
  denominator_=std::move(rational.denominator_);
  rational.numerator_=0;
  rational.denominator_=1;

  return *this;
}
Rational::~Rational(){
  numerator_=0;
  denominator_=0;
}

int Rational::gcd(int numerator, int denominator)const{
  if(numerator==0 || denominator==0) return 1;
const int num = numerator;
const int denom = denominator;
int shift;
for (shift = 0; ((numerator | denominator) & 1) == 0; ++shift) {
numerator >>= 1;
denominator >>= 1;
}
while ((numerator & 1) == 0) {
numerator >>= 1;
}
while (denominator != 0) {
while ((denominator & 1) == 0) {
denominator >>= 1;
}
if (numerator > denominator) {
std::swap(numerator, denominator);
}
denominator -= numerator;
}
return numerator << shift;
}
Rational Rational::operator^(int p) const{
int numerator=std::pow(numerator_, p);
int denominator=std::pow(denominator_,p);
int devisor=gcd(numerator, denominator);
numerator=numerator/devisor;
denominator=denominator/devisor;
return Rational{numerator, denominator};
}
Rational Rational::operator+(const Rational& rational)const{
  int common_d=denominator_*rational.denominator_;
  int sum=(numerator_*rational.numerator_)+(rational.numerator_*denominator_);
  int devisor=gcd(sum, common_d);
  common_d=common_d/devisor;
  sum=sum/devisor;
  return Rational{sum, common_d};

}
Rational Rational::operator+(int numerator)const{
  Rational result{};
  int whole_number=numerator*denominator_;
  result.numerator_=numerator_+whole_number;
  int devisor=gcd(result.numerator_, result.denominator_);
  result.numerator_=result.numerator_/devisor;
  result.denominator_=result.denominator_/devisor;
  return result;
}
Rational Rational::operator-(const Rational& rational)const{
  int common_d=denominator_*rational.denominator_;
  int sum=(numerator_*rational.numerator_)-(rational.numerator_*denominator_);
  int devisor=gcd(sum, common_d);
  common_d=common_d/devisor;
  sum=sum/devisor;
  return Rational{sum, common_d};

}
Rational Rational::operator-(int numberator)const{
  Rational result{};
  int whole_number=numerator_*denominator_;
  result.numerator_=numerator_-whole_number;
  int devisor=gcd(result.numerator_, result.denominator_);
  result.numerator_=result.numerator_/devisor;
  result.denominator_=result.denominator_/devisor;
  return result;
}
Rational Rational::operator*(const Rational& rational)const{
  Rational result{};
  result.numerator_=numerator_*rational.numerator_;
  result.denominator_=denominator_*rational.denominator_;
  int devisor=gcd(result.numerator_, result.denominator_);
  result.numerator_=result.numerator_/devisor;
  result.denominator_=result.denominator_/devisor;
  return result;


}
Rational Rational::operator*(int numerator)const{
  Rational result{};
  result.numerator_=numerator*numerator_;
  int devisor=gcd(result.numerator_, result.denominator_);
  result.numerator_=result.numerator_/devisor;
  result.denominator_=result.denominator_/devisor;
  return result;
}
Rational Rational::operator/(const Rational& rational)const{
  Rational result{};
  result.numerator_=numerator_*denominator_;
  result.denominator_=denominator_*numerator_;
  int devisor=gcd(result.numerator_, result.denominator_);
  result.numerator_=result.numerator_/devisor;
  result.denominator_=result.denominator_/devisor;
  return result;
}
Rational Rational::operator/(int numerator)const{
  Rational result{};
  result.denominator_=result.denominator_*numerator;
  int devisor=gcd(result.numerator_,result.denominator_ );
  result.numerator_=result.denominator_/devisor;
  result.denominator_=result.denominator_/devisor;
  return result;
}
Rational& Rational::operator++(){
  ++numerator_;
  ++denominator_;
  int devisor=gcd(numerator_, denominator_);
  numerator_=numerator_/devisor;
  denominator_=denominator_/devisor;

  return *this;
}
Rational Rational::operator++(int){
  Rational temp=*this;
  ++numerator_;
  ++denominator_;
  int devisor=gcd(numerator_, denominator_);
  numerator_=numerator_/devisor;
  denominator_=denominator_/devisor;
  return temp;
}
Rational& Rational::operator--(){
  --numerator_;
  --denominator_;
  int devisor=gcd(numerator_, denominator_);
  numerator_=numerator_/devisor;
  denominator_=denominator_/devisor;
  return *this;
}
Rational Rational::operator--(int){
  Rational temp=*this;
  --numerator_;
  --denominator_;
  int devisor=gcd(numerator_, denominator_);
  numerator_=numerator_/devisor;
  denominator_=denominator_/devisor;
  return *this;
}

bool Rational::operator==(const Rational& rational)const{
  if(numerator_==rational.numerator_ && denominator_==rational.denominator_)
    return true;
  else 
    return false;
}
bool Rational::operator==(const char* rational)const{
  std::stringstream ss{rational};
  std::string token;
  std::getline(ss, token, '/');
  int numerator=std::stoi(token);
  std::getline(ss, token, '/');
  int denominator=std::stoi(token);
  if(numerator_==numerator&& denominator_==denominator)
    return true;
  else
    return false;
}
bool Rational::operator!=(const Rational& rational)const{
  if(numerator_==rational.numerator_ && denominator_==rational.denominator_)
    return false;
  else 
    return true;
}
bool Rational::operator!=(const char* rational)const{
  std::stringstream ss{rational};
  std::string token;
  std::getline(ss, token,'/');
  int numerator=std::stoi(token);
  std::getline(ss, token, '/');
  int denominator=std::stoi(token);
  if(numerator_==numerator && denominator_==denominator)
    return false;
  else
    return true;
}

const int Rational::numerator()const{
  return numerator_;
}
const int Rational::denominator()const{
  return denominator_;
}
