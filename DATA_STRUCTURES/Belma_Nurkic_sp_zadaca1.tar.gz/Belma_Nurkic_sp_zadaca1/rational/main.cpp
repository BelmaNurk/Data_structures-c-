#include "Rational.hpp"
#include<iostream>
#include<fstream>
#include<sstream>
#include<vector>

int main(int argc, char* argv[]) {
  std::string line;
  std::ifstream is{"input.txt"};
  std::getline(is, line);
  std::vector<int> numbers;
  std::vector<Rational> rational_numbers;
  while(std::getline(is, line)){
    std::stringstream ss{line};
    std::string token;
    while(std::getline(ss, token, '/')){
      //for(int i=0; i<token.size(); ++i){
      //  if(!isdigit(token[i]) || token[i]=='0')
      //    throw std::invalid_argument("");
      //}
      int number=std::stoi(token);
      numbers.push_back(number);
    }
  }
  for(int i=0; i<numbers.size()-1; ++i){
    Rational rational_number;
    rational_number.numerator_=numbers.at(i);
    rational_number.denominator_=numbers.at(i+1);
    rational_numbers.push_back(rational_number);
  }

  std::cout<<rational_numbers.at(0).numerator_<<" "<<rational_numbers.at(0).denominator_<<std::endl;
  //testing default con
  Rational rational1{};
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  //testing para con
  Rational rational2{2,2};
  std::cout<<rational2.numerator()<<" "<<rational2.denominator()<<std::endl;
  //testing move con
  Rational rational3=std::move(rational_numbers.at(3));
  std::cout<<rational3.numerator()<<" "<<rational3.denominator()<<std::endl;
  // testing copy op =
  rational1=std::move(rational3);
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  //testing move op =
  rational2=rational_numbers.at(2);
  std::cout<<rational2.numerator()<<" "<<rational2.denominator()<<std::endl;


  // testing operator +
  rational1=rational2+rational3;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  rational1=rational1+5;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  
  // testing operator *
  rational1=rational2*rational3;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  rational1=rational1*5;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  
  // testing operator /
  rational1=rational2/rational3;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  rational1=rational1/5;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  
  // testing operator -
  rational1=rational2-rational3;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;
  rational1=rational1-5;
  std::cout<<rational1.numerator()<<" "<<rational1.denominator()<<std::endl;

  // testing ++  and --
  Rational rational4{1,1};
  ++rational4;
  ++rational4;
  --rational4;
  --rational4;
  std::cout<<rational4.numerator()<<" "<<rational4.denominator()<<std::endl;

  // testing != and ==
  Rational rational5{2,2};
  bool b=rational4==rational5;
  std::cout<<b<<std::endl;
  --rational5;
  bool c=rational5!=rational4;
  std::cout<<c<<std::endl;

  
  
  


  return 0;

}
