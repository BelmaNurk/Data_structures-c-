#include "duration.hpp"
#include<iomanip>
#include<iostream>
#include<sstream>
#include<string>

Duration::Duration():sec_{0}, min_{0}, hour_{0}{}
Duration::Duration(size_t seconds){
  hour_=seconds/3600;
  min_=(seconds%3600)/60;
  sec_=seconds%60;
}
Duration::Duration(size_t hours, size_t minutes, size_t seconds){
  if(minutes>=60 || seconds>=60){
    throw std::out_of_range("jj");
  }
  sec_=seconds;
  min_=minutes;
  hour_=hours;
}

Duration::Duration(const std::string& obj){
  std::stringstream ss(obj);
  char separator;
  ss>>hour_>>separator>>min_>>separator>>sec_;
}


size_t Duration::get_s()const{return sec_;}
size_t Duration::get_m()const{return min_;}
size_t Duration::get_h()const{return hour_;}

Duration& Duration::set_s(size_t seconds){
  if(seconds>=60 ||seconds<0)
    throw std::out_of_range(" ");
    else if(sec_==0 || hour_==0 || min_==0)
      sec_=seconds;
    else
      sec_=seconds;
  return *this;
}

Duration& Duration::set_m(size_t minutes){
  if(minutes>=60 || minutes<0)
    throw std::out_of_range("d");
  min_=minutes;
  return *this;
}

Duration& Duration::set_h(size_t hour){
  if(hour<0||hour>=60)
    throw std::out_of_range("k");
  hour_=hour;
  return *this;
}

bool Duration::operator==(const Duration& other)const{
  if(other.sec_==sec_&&other.min_==min_&&other.hour_==hour_)
    return true;
  else
    return false;
}

bool Duration::operator!=(const Duration& other)const{
  if(other.sec_==sec_&&other.min_==min_&&other.hour_==hour_)
    return false;
  else
    return true;
}
bool Duration::operator>(const Duration& other)const{
  if(hour_>other.hour_){
    return true;
  }
  else if(hour_==other.hour_){
    if(min_>other.min_){
      return true;
    }
    else if(min_==other.min_){
      if(sec_>other.sec_){
        return true;
      }
    }
  }
    return false;
  }
bool Duration::operator<(const Duration& other)const{
  if(hour_<other.hour_)
    return true;
  else if(hour_==other.hour_){
    if(min_<other.min_){
      return true;
    }
    else if(min_==other.min_){
      if(sec_<other.sec_)
        return true;
    }
  }

    return false;
}


bool Duration::operator<=(const Duration& other)const{
  if(hour_<other.hour_)
    return true;
  else if(hour_==other.hour_){
    if(min_<other.min_){
      return true;
    }
    else if(min_==other.min_){
      if(sec_<=other.sec_)
        return true;
    }
  }
  return false;
}

bool Duration::operator>=(const Duration& other)const{
  if(hour_>other.hour_){
    return true;
}
  else if(hour_==other.hour_){
    if(min_>other.min_){
      return true;
    }
    else if(min_==other.min_){
      if(sec_>=other.sec_){
        return true;
      }
    }
  }
  return false;
}

Duration& Duration::operator+=(const Duration& other){
  sec_+=other.sec_;
  min_+=other.min_;
  hour_+=other.hour_;

  min_=min_*60;
  hour_=hour_*3600;

  sec_=sec_+min_+hour_;
  hour_=sec_/3600;
  min_=(sec_%3600)/60;
  sec_=sec_%60;
  return *this;
}

Duration Duration::operator+(const Duration& other)const{
  Duration newD;
  newD.sec_=sec_+other.sec_;
  newD.min_=min_+other.min_;
  newD.hour_=hour_+other.hour_;

  newD.sec_=newD.sec_+newD.min_*60+newD.hour_*3600;

  newD.hour_=newD.sec_/3600;
  newD.min_=(newD.sec_%3600)/60;
  newD.sec_=newD.sec_%60;
  return newD;
  
}

Duration& Duration::operator-=(const Duration& other){
  if(*this<other)
    throw std::out_of_range("");
  sec_-=other.sec_;
  min_-=other.min_;
  hour_-=other.hour_;

  sec_=sec_+min_*60+hour_*3600;
  hour_=sec_/3600;
  min_=(sec_%3600)/60;
  sec_=sec_%60;
  return *this;
}

Duration Duration::operator-(const Duration& other)const{
  Duration newD{};
  newD.sec_=sec_-other.sec_;
  if(*this<other)
    throw std::out_of_range("");
  newD.min_=min_-other.min_;
  newD.hour_=hour_-other.hour_;

  newD.sec_=newD.sec_+newD.min_*60+newD.hour_*3600;
  newD.hour_=newD.sec_/3600;
  newD.min_=(newD.sec_%3600)/60;
  newD.sec_=newD.sec_%60;
  return newD;
}

Duration& Duration::operator*=(const Duration& other){
  int total_seconds=(hour_*3600)+(min_*60)+sec_;
  int othet_total_secnds=(other.hour_)*3600+(other.min_)*60+other.sec_;
  total_seconds*=othet_total_secnds;
  hour_=total_seconds/3600;
  total_seconds%=3600;
  min_=total_seconds/60;
  sec_=total_seconds%60;

  if(min_>=60){
    hour_+=min_/60;
    min_%=60;
  }
  if(sec_>=60){
    min_+=sec_/60;
    sec_%=60;
  }

  return *this;
}

Duration Duration::operator*(const Duration& other)const{
  Duration newD{};
  newD.sec_=sec_*other.sec_;
  newD.min_=min_*other.min_;
  newD.hour_=hour_*other.hour_;

  newD.sec_=newD.sec_+newD.min_*60+newD.hour_*3600;
  newD.hour_=newD.sec_/3600;
  newD.min_=(newD.sec_%3600)/60;
  newD.sec_=newD.sec_%60;
  return newD;
}

Duration& Duration::operator*(int factor){
  sec_*=factor;
  min_*=factor;
  hour_*=factor;
  sec_=sec_+min_*60+hour_*3600;
  hour_=sec_/3600;
  min_=(sec_%3600)/60;
  sec_=sec_%60;
  return *this;
}
Duration Duration::operator/(const Duration& other)const{
  Duration newD{};
  newD.sec_=sec_/other.sec_;
  newD.min_=min_/other.min_;
  newD.hour_=hour_/other.hour_;

  return newD;
}

Duration& Duration::operator/=(const Duration& other){
  int total_seconds=(hour_*3600)+(min_*60)+sec_;
  int total_seconds_other=(other.hour_)*3600+(other.min_)*60+other.sec_;
  total_seconds/=total_seconds_other;

  hour_=total_seconds/3600;
  total_seconds%=3600;
  min_=total_seconds/60;
  sec_=total_seconds%60;

  if(min_>=60){
    hour_+=min_/60;
    min_%=60;

  }

  if(sec_>=60){
    min_+=sec_/60;
    sec_%=60;
  }
  return *this;
}

std::ostream& operator<<(std::ostream& out, const Duration& obj){
  out<<std::setfill('0')<<std::setw(2)<<obj.get_h()<<":"
    <<std::setw(2)<<obj.get_m()<<":"
    <<std::setw(2)<<obj.get_s();

  return out;
}

std::istream& operator>>(std::istream& in, Duration& obj){
  std::string s;
  in>>s;
  std::stringstream ss(s);
  std::string token;
  int hour, minu, sec;
  std::getline(ss, token, ':');
  hour=std::stoi(token);
  std::getline(ss, token, ':');
  minu=std::stoi(token);
  std::getline(ss, token, ':');
  sec=std::stoi(token);

  obj.set_h(hour);
  obj.set_m(minu);
  obj.set_s(sec);


  return in;
  
}

