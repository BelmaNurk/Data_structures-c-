#pragma once
#include<iostream>
class Duration {
  public:
  Duration();
  size_t get_s()const;
  size_t get_m()const;
  size_t get_h()const;

  Duration(size_t seconds);
  Duration(size_t hours, size_t minutes, size_t seconds);
  Duration(const std::string& obj);

  Duration& set_s(size_t seconds);
  Duration& set_m(size_t minutes);
  Duration& set_h(size_t hours);

operator bool()const{return (sec_!=0)||(min_!=0) || (hour_!=0); }

bool operator!()const{
  return !operator bool();
}

  bool operator==(const Duration& other)const;
  bool operator!=(const Duration& other)const;
  bool operator<(const Duration& other)const;
  bool operator>(const Duration& other)const;
  bool operator>=(const Duration& other)const;
  bool operator<=(const Duration& other)const;

  Duration& operator+=(const Duration& other);
  Duration operator+(const Duration& other)const;
  Duration& operator-=(const Duration& other);
  Duration operator-(const Duration& other)const;
  Duration operator*(const Duration& other)const;
  Duration& operator*(int factor);
  Duration& operator*=(const Duration& other);
  Duration operator/(const Duration& other)const;
  Duration& operator/=(const Duration& other);


  private:
    size_t sec_=0;
    size_t min_=0;
    size_t hour_=0;
};

std::ostream& operator<<(std::ostream& out,const Duration& obj);
std::istream& operator>>(std::istream& in, Duration& obj);
